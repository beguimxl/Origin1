package com.example.grade

import android.os.Bundle
import android.support.v7.app.AppCompatActivity
import android.view.View
import com.example.myapplication.R

import kotlinx.android.synthetic.main.activity_main.*

class MainActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

//        var java=findViewById<View>(R.id.editTextJava) as EditText
//        var network=findViewById<View>(R.id.editTextNetwork) as EditText
//        var database=findViewById<View>(R.id.editTextDatabase) as EditText
//        var total=findViewById<View>(R.id.editTextTotal) as EditText
//        var ave=findViewById<View>(R.id.editTextAve) as EditText
//        var grade=findViewById<View>(R.id.editTextGrade) as EditText

        var java = 0
        var net = 0
        var database = 0
        var total = 0
        var ave = 0

        java = editTextJava.text.toString().toInt()
        net = editTextNetwork.text.toString().toInt()
        database = editTextDatabase.text.toString().toInt()


//        buttonTotal.setOnClickListener(View.OnClickListener {
//            editTextTotal.text=( editTextJava.text.toString().toInt()+editTextNetwork.text.toString().toInt()+editTextDatabase.text.toString().toInt())

//        })

        buttonTotal.setOnClickListener {
            total = java + net + database
            editTextTotal.setText(total)
        }

        buttonAve.setOnClickListener {
            ave = total / 3
        }

//        buttonAve.setOnClickListener(View.OnClickListener {
//            editTextAve.text=( editTextJava.text.toString().toInt()+editTextNetwork.text.toString().toInt()+editTextDatabase.text.toString().toInt())/3
//        })





    }
}